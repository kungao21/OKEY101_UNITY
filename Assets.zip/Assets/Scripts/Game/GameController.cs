﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameController : MonoBehaviour
{
    [Header("HUD")]
    public TMP_Text txtPlayers;
    public TMP_Text txtCountdown;



    [Header("BUILD PILES (DagitmaAlani)")]
    public Transform mainContainer;
    public Transform rightContainer;
    public Transform topContainer;
    public Transform leftContainer;

    [Header("ISTAKALAR (Hands)")]
    public Transform mainRack;
    public Transform rightRack;
    public Transform topRack;
    public Transform leftRack;


    public GameObject arkaPrefab; // ARKA prefab

    [Header("Layout")]
    public float pileXStep = 0.035f;   // Deste kolonlari arasi X
    public float tileYStep = 0.004f;   // Kolon icinde taslarin Y stack farki
    public float dealFlySeconds = 0.30f;    // kisa lineer ucus







    private WsClient _ws;

    // ===== DEALING visual cache =====
    private bool _hasLast = false;
    private int _lastDealLeft = -1;
    private int _lastDealCursor = 0;
    private int _lastDealSeatCursor = 0;

    // last pileCounts (1..15)
    private readonly int[] _lastPileCounts = new int[16];

    // last myHand
    private List<string> _lastMyHand = new List<string>();

    // pileId -> pileRoot (RenderBuildPiles içinde doldurulacak)
    private readonly Dictionary<int, Transform> _pileRootById = new Dictionary<int, Transform>();

    // Tas prefab cache (Resources/taslar/R01 vb)
    private readonly Dictionary<string, GameObject> _tilePrefabCache = new Dictionary<string, GameObject>();


    void Start()
    {
        _ws = FindObjectOfType<WsClient>();
        if (_ws == null)
        {
            Debug.LogError("[Game] WsClient not found. NetworkClient sahneler arası taşınıyor mu?");
            return;
        }

        _ws.OnMessage += OnWsMessage;

        // ✅ İlk açılışta "0/4" basma. Snapshot varsa onu uygula.
        if (_ws.LastRoomSnapshot != null)
        {
            OnWsMessage(_ws.LastRoomSnapshot);
        }
        else
        {
            // Snapshot gelene kadar placeholder
            if (txtPlayers != null) txtPlayers.SetText("Oyuncu: --/4");
            SetCountdown(null);
        }
    }

    void OnDestroy()
    {
        if (_ws != null) _ws.OnMessage -= OnWsMessage;
    }

    private void OnWsMessage(JObject obj)
    {
        var t = obj.Value<string>("t");
        if (t != "ROOM_SNAPSHOT") return;

        var p = obj["p"] as JObject;
        if (p == null) return;

        // players sayısı
        int count = CountPlayers(p["players"] as JObject);
        SetPlayers(count);

        // state ve autostartLeft
        var state = p.Value<string>("state") ?? "";
        if (state == "AUTO_START")
        {
            int left = p.Value<int?>("autoStartLeft") ?? 0;
            SetCountdown(left);
        }
        else
        {
            SetCountdown(null);
        }

        // ✅ Önce DEALING tick yakala (eski pileRoot'lar hala duruyor)
        if (state == "DEALING")
        {
            HandleDealingTick(p);
        }

        // ✅ Sonra render et (pileRoot map temizlenip yeniden kurulacak)
        if (state == "BUILD_PILES" || state == "DICE" || state == "DEALING")
        {
            RenderBuildPiles(p);
        }

        CacheLastSnapshot(p);


    }

    private int CountPlayers(JObject playersObj)
    {
        if (playersObj == null) return 0;

        int n = 0;
        foreach (var prop in playersObj.Properties())
        {
            var pj = prop.Value as JObject;
            if (pj == null) continue;

            var userId = pj.Value<string>("userId") ?? "";
            if (!string.IsNullOrEmpty(userId)) n++;
        }
        return n;
    }

    private void SetPlayers(int count)
    {
        if (txtPlayers == null) return;
        txtPlayers.SetText("Oyuncu: {0}/4", count);
        Canvas.ForceUpdateCanvases();
    }

    private void SetCountdown(int? secondsLeft)
    {
        if (txtCountdown == null) return;

        if (secondsLeft.HasValue)
            txtCountdown.SetText("Başlıyor: {0}", secondsLeft.Value);
        else
            txtCountdown.SetText("");
    }

    // ===================== BUILD PILES =====================

    private void RenderBuildPiles(JObject p)
    {
        // gerekli referanslar yoksa sessizce çık
        if (mainContainer == null || rightContainer == null || topContainer == null || leftContainer == null) return;
        if (arkaPrefab == null) return;

        _pileRootById.Clear();


        // mySeat bul (WsClient içinde LocalUserId tutuyor olmalısın; sende yoksa söyle, ekleriz)
        int mySeat = FindMySeat(p["players"] as JObject);
        if (mySeat == 0) return;

        var seatToContainer = BuildSeatToContainerMap(mySeat);

        // temizle
        ClearChildren(mainContainer);
        ClearChildren(rightContainer);
        ClearChildren(topContainer);
        ClearChildren(leftContainer);

        var owners = p["pileOwners"] as JObject;
        var counts = p["pileCounts"] as JObject;
        if (owners == null || counts == null) return;

        // her seat için kolon index
        var colIndexBySeat = new Dictionary<int, int> { { 1, 0 }, { 2, 0 }, { 3, 0 }, { 4, 0 } };

        // 1..15 desteyi sırayla çiz
        for (int pileId = 1; pileId <= 15; pileId++)
        {
            int c = counts.Value<int?>($"{pileId}") ?? 0;
            if (c <= 0) continue;

            int ownerSeat = owners.Value<int?>($"{pileId}") ?? 0;
            if (ownerSeat < 1 || ownerSeat > 4) continue;

            if (!seatToContainer.TryGetValue(ownerSeat, out var container))
                continue;

            int k = colIndexBySeat[ownerSeat];
            colIndexBySeat[ownerSeat] = k + 1;

            // ✅ Senin istediğin kolon mantığı:
            // Deste1 X=0, Deste2 X=0.035, Deste3 X=0.070, ...
            var pileRoot = new GameObject($"Pile_{pileId}_S{ownerSeat}").transform;
            pileRoot.SetParent(container, false);
            pileRoot.localPosition = new Vector3(k * pileXStep, 0f, 0f);
            pileRoot.localRotation = Quaternion.identity;

            _pileRootById[pileId] = pileRoot;


            // ✅ Taşlar aynı X’te, Y’de 0.004 artarak stack
            for (int i = 0; i < c; i++)
            {
                var go = Instantiate(arkaPrefab, pileRoot, false);
                go.transform.localPosition = new Vector3(0f, 0f, i * tileYStep);
                go.transform.localRotation = Quaternion.identity;
            }
        }
    }

    private int FindMySeat(JObject playersObj)
    {
        if (playersObj == null) return 0;
        if (_ws == null) return 0;

        // ⚠️ Burada WsClient'te LocalUserId olması lazım
        var myId = _ws.LocalUserId;
        if (string.IsNullOrEmpty(myId)) return 0;

        foreach (var prop in playersObj.Properties())
        {
            var pj = prop.Value as JObject;
            if (pj == null) continue;

            var uid = pj.Value<string>("userId") ?? "";
            if (uid == myId)
                return pj.Value<int?>("seat") ?? 0;
        }
        return 0;
    }

    private Dictionary<int, Transform> BuildSeatToContainerMap(int mySeat)
    {
        int right = NextSeat(mySeat);
        int top = NextSeat(right);
        int left = NextSeat(top);

        return new Dictionary<int, Transform>
        {
            { mySeat, mainContainer },
            { right, rightContainer },
            { top, topContainer },
            { left, leftContainer },
        };
    }

    private int NextSeat(int s) => (s == 4) ? 1 : s + 1;

    private void ClearChildren(Transform t)
    {
        for (int i = t.childCount - 1; i >= 0; i--)
            Destroy(t.GetChild(i).gameObject);
    }



    // ===================== DEALING VISUAL =====================

    private void CacheLastSnapshot(JObject p)
    {
        _lastDealLeft = p.Value<int?>("dealLeft") ?? -1;
        _lastDealCursor = p.Value<int?>("dealCursor") ?? 0;
        _lastDealSeatCursor = p.Value<int?>("dealSeatCursor") ?? 0;

        var counts = p["pileCounts"] as JObject;
        if (counts != null)
        {
            for (int i = 1; i <= 15; i++)
                _lastPileCounts[i] = counts.Value<int?>($"{i}") ?? 0;
        }

        _lastMyHand = ReadMyHand(p);
        _hasLast = true;
    }

    private void HandleDealingTick(JObject p)
    {
        if (!_hasLast) return;

        int dealLeftNow = p.Value<int?>("dealLeft") ?? -1;
        if (dealLeftNow < 0) return;

        // dealLeft azaldıysa: bu tick'te 1 deste dağıtıldı
        if (dealLeftNow < _lastDealLeft)
        {
            int pileId = _lastDealCursor;
            int targetSeat = _lastDealSeatCursor;

            int count = (pileId >= 1 && pileId <= 15) ? _lastPileCounts[pileId] : 0;
            if (count <= 0) count = 7;

            Vector3 src = mainContainer != null ? mainContainer.position : Vector3.zero;
            Quaternion srcRot = Quaternion.identity;

            if (_pileRootById.TryGetValue(pileId, out var pileRoot) && pileRoot != null)
            {
                src = pileRoot.position;
                srcRot = pileRoot.rotation;
            }

            StartCoroutine(FlyBundleThenResolve(p, pileId, targetSeat, count, src, srcRot));

        }
    }

    private System.Collections.IEnumerator FlyBundleThenResolve(JObject p, int pileId, int targetSeat, int count, Vector3 src, Quaternion srcRot)

    {
        // rack referansları zorunlu (bu dosyada yeni ekledik)
        if (mainRack == null || rightRack == null || topRack == null || leftRack == null) yield break;

        int mySeat = FindMySeat(p["players"] as JObject);
        if (mySeat == 0) yield break;

        var seatToRack = BuildSeatToRackMap(mySeat);
        if (!seatToRack.TryGetValue(targetSeat, out var rack) || rack == null) yield break;

        Vector3 dst = rack.position;

        // ✅ bundle = arkaPrefab
        var bundle = Instantiate(arkaPrefab);
        bundle.transform.position = src;
        bundle.transform.rotation = srcRot;   // ✅ uçarken dikleşmesin


        // lineer uçuş
        float t = 0f;
        float seconds = Mathf.Max(0.01f, dealFlySeconds);
        while (t < 1f)
        {
            t += Time.deltaTime / seconds;
            float a = Mathf.Clamp01(t);
            if (bundle != null)
                bundle.transform.position = Vector3.Lerp(src, dst, a);
            yield return null;
        }

        bool isMine = (targetSeat == mySeat);

        // Bana değilse: varınca sil
        if (!isMine)
        {
            Destroy(bundle);
            yield break;
        }

        var nowHand = ReadMyHand(p);
        var newTiles = MultiSetDiff(_lastMyHand, nowHand);

        // ✅ myHand diff boşsa: bundle'ı SİLME, rack'e bırak (placeholder)
        if (newTiles == null || newTiles.Count == 0)
        {
            bundle.transform.SetParent(rack, true);
            bundle.transform.position = dst;
            bundle.transform.rotation = srcRot; // düz kalsın
            yield break;
        }

        // ✅ doluysa: bundle sil + gerçek taşları spawn et
        Destroy(bundle);
        SpawnMyTilesOnRack(rack, newTiles);

    }

    private Dictionary<int, Transform> BuildSeatToRackMap(int mySeat)
    {
        int right = NextSeat(mySeat);
        int top = NextSeat(right);
        int left = NextSeat(top);

        return new Dictionary<int, Transform>
    {
        { mySeat, mainRack },
        { right, rightRack },
        { top, topRack },
        { left, leftRack },
    };
    }

    private List<string> ReadMyHand(JObject p)
    {
        var list = new List<string>();
        var arr = p["myHand"] as JArray;
        if (arr == null) return list;

        foreach (var it in arr)
        {
            var s = it?.ToString() ?? "";
            if (!string.IsNullOrEmpty(s)) list.Add(s);
        }
        return list;
    }

    // after - before (multiset)
    private List<string> MultiSetDiff(List<string> before, List<string> after)
    {
        var cnt = new Dictionary<string, int>();
        if (before != null)
        {
            foreach (var s in before)
            {
                if (cnt.ContainsKey(s)) cnt[s]++;
                else cnt[s] = 1;
            }
        }

        var res = new List<string>();
        if (after != null)
        {
            foreach (var s in after)
            {
                if (cnt.TryGetValue(s, out var n) && n > 0) cnt[s] = n - 1;
                else res.Add(s);
            }
        }
        return res;
    }

    private void SpawnMyTilesOnRack(Transform rack, List<string> tileIds)
    {
        if (rack == null) return;

        // Şimdilik: gelen taşları rack altında yan yana dizeriz (pileXStep kullanıyoruz, yeni layout yok)
        foreach (var tileId in tileIds)
        {
            string prefabName = TileIdToPrefabName(tileId);
            var prefab = LoadTilePrefab(prefabName);

            if (prefab == null) continue;

            var go = Instantiate(prefab, rack, false);
            int idx = rack.childCount - 1;
            go.transform.localPosition = new Vector3(idx * pileXStep, 0f, 0f);
            go.transform.localRotation = Quaternion.identity;
        }
    }

    private string TileIdToPrefabName(string tileId)
    {
        // "R01-2" -> "R01"
        int dash = tileId.IndexOf('-');
        return dash > 0 ? tileId.Substring(0, dash) : tileId;
    }

    private GameObject LoadTilePrefab(string prefabName)
    {
        if (string.IsNullOrEmpty(prefabName)) return null;

        if (_tilePrefabCache.TryGetValue(prefabName, out var cached) && cached != null)
            return cached;

        // ⚠️ Resources şart: Assets/Resources/taslar/R01.prefab
        var prefab = Resources.Load<GameObject>($"taslar/{prefabName}");
        _tilePrefabCache[prefabName] = prefab;
        return prefab;
    }

}
